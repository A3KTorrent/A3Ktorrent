A3ktorrent is a Bitorrent client with support for http as well as udp trackers. Its is implemented fully in python. Twisted has been used for the purpose of networking. GUI feature is also added in this project. GTK 3+ with glade has been used for implementing it.

MODULES NEEDED: Bencode GTK3+ bitstring requests twisted